<?php
require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

// Fetch user data sorted by ID in descending order
$users = $database->select('users', '*', ['ORDER' => ['id' => 'DESC']]);

// Prepare the response
header('Content-Type: application/json');
echo json_encode($users, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
?>
