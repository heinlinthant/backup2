<?php
    include "sessionCheck.php";
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Check User Data</title>
    <!-- Link to your local Bootstrap 5 CSS file -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <!-- Link to your custom styles -->
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
        }

        .container {
            background-color: #1e1e1e;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            max-width: 600px;
            margin-top: 2rem;
        }

        .form-dark .form-control {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border: 1px solid #444;
            font-family: Arial, sans-serif;
        }

        .form-dark .form-control:focus {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border-color: #00ff88;
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.25);
        }

        .form-label {
            color: #e0e0e0;
        }

        .btn-primary {
            background-color: #00ff88;
            border: none;
            color: #000000;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #00cc6a;
            transform: scale(1.05);
        }

        .btn-primary:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.5);
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h2 class="text-light text-center">Check User Data</h2>
        <form action="activate.php" method="get" class="form-dark">
            <div class="mb-3">
                <label for="username" class="form-label">Key</label>
                <input type="text" class="form-control" id="username" name="users_key" maxlength="10"required>
            </div>
            <div class="mb-3">
                <label for="deviceId" class="form-label">Device ID</label>
                <input type="text" class="form-control" id="deviceId" name="deviceId" maxlength="30" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Check User</button>
        </form>
    </div>

    <!-- Link to your local Bootstrap 5 JS file -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
