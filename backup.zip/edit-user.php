<?php

include "sessionCheck.php";

require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

// Get user ID from query parameter
$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;

$user = $database->get('users', '*', ['id' => $userId]);

if (!$user) {
    echo 'User not found.';
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Edit User</title>
    <!-- Link to your local Bootstrap 5 CSS file -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column; /* Allows stacking the containers vertically */
        }

        .container {
            background-color: #1e1e1e;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            max-width: 600px;
            margin-top: 2rem;
        }

        .form-dark .form-control {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border: 1px solid #444;
            font-family: 'Arial', sans-serif;
        }

        .form-dark .form-control:focus {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border-color: #00ff88;
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.25);
        }

        .btn-primary {
            background-color: #00ff88;
            border: none;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #00cc6a;
            transform: scale(1.05);
        }

        .btn-primary:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.5);
        }

        .form-label {
            color:  #00ff88;
        }
    </style>
</head>
<body>
    <div class="container">
        <h2 class="text-center h3" style="color:#00ff88">Edit User</h2>
        <form method="post" action="edit.php" class="form-dark">
            <input type="hidden" name="id" value="<?php echo htmlspecialchars($user['id']); ?>">
            <div class="mb-3">
                <label for="username" class="form-label">Username</label>
                <input type="text" id="username" name="username" class="form-control" maxlength="30" value="<?php echo htmlspecialchars($user['username']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="key" class="form-label">Key</label>
                <input type="text" id="key" name="users_key" class="form-control" maxlength="10"value="<?php echo htmlspecialchars($user['users_key']); ?>" required>
            </div>
            <div class="mb-3">
                <label for="deviceId" class="form-label">Device ID</label>
                <input type="text" id="deviceId" name="deviceId" class="form-control" maxlength="30" value="<?php echo htmlspecialchars($user['deviceId']); ?>">
            </div>
            <div class="mb-3">
                <label for="subscription" class="form-label">Subscription (days)</label>
                <input type="number" min="1" id="subscription" name="subscription" class="form-control" value="<?php echo htmlspecialchars($user['subscription']); ?>" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Update</button>
        </form>
    </div>

    <!-- Link to your local Bootstrap 5 JS file (optional) -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
