<?php
require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

// Initialize the response array
$response = [
    'permission' => 'no',
    'expireDate' => ''
];

// Check if the request method is POST
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the form data
    $username = $_POST['username'];
    $password = $_POST['password'];
    $deviceId = $_POST['deviceId'];

    // Fetch the user data from the database
    $user = $database->get('users', '*', [
        'username' => $username,
        'password' => $password,
        'deviceId' => $deviceId
    ]);

    // Check if the user exists
    if ($user) {
        // Get the current date
        $currentDate = new DateTime();
        $expireDate = new DateTime($user['expireDate']);

        // Determine if the user's subscription has expired
        if ($expireDate >= $currentDate) {
            $response['permission'] = 'yes';
            $response['expireDate'] = $user['expireDate'];
        } else {
            $response['expireDate'] = $user['expireDate'];
        }
    }

    // Return the response as JSON
    header('Content-Type: application/json');
    echo json_encode($response);
}
?>
