<?php

    include 'sessionCheck.php';

    $oldData = file_get_contents('admin.txt');
    $data = json_decode($oldData, true);
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    
            $username = htmlspecialchars(trim($_POST['username']));
            $password = htmlspecialchars(trim($_POST['password']));

            $adminData = array(
                "username" => $username,
                "password" => $password
            );

            $jsonData = json_encode($adminData, JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
            file_put_contents("admin.txt", $jsonData);

            session_start();
            session_unset(); // Unset session variables
            session_destroy(); // Destroy the session
            header("Location: login.php"); // Redirect to login page
            exit();
    }

?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Change Info</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #1e1e1e;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            max-width: 600px;
            width: 100%;
        }

        .form-control {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border: 1px solid #444;
            font-family: Arial, sans-serif;
        }

        .form-control:focus {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border-color: #00ff88;
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.25);
        }

        .btn-primary {
            background-color: #00ff88;
            border: none;
            color: #000000;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #00cc6a;
            transform: scale(1.05);
        }

        .btn-primary:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.5);
        }

        .form-label {
            color: #e0e0e0;
        }
    </style>
</head>
<body>
    <div class="container mt-5">
        <h5 class="text-center">Your current username is: <span class="text-light"><?php echo $data["username"]; ?></span></h5>
        <h5 class="text-center">Your current password is: <span class="text-light"><?php echo $data["password"]; ?></span></h5>
        <form action="change-admin.php" method="post">
            <div class="mb-3">
                <label for="username" class="form-label">New Username</label>
                <input type="text" class="form-control" id="username" name="username" required>
            </div>
            <div class="mb-3">
                <label for="password" class="form-label">New Password</label>
                <input type="password" class="form-control" id="password" name="password" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Change Info</button>
        </form>
    </div>

    <!-- Link to your local Bootstrap 5 JS file (optional) -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
