<?php
date_default_timezone_set('Asia/Rangoon');
include "sessionCheck.php";
require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

// Get the current date
$currentDate = new DateTime();

// Delete all expired users
$database->delete('users', [
    'expireDate[<]' => $currentDate->format('Y-m-d')
]);

// Check if an ID is provided to delete a specific user
if (isset($_GET['id'])) {
    $userId = intval($_GET['id']); // Sanitize the user ID to an integer

    // Delete the specific user
    $database->delete('users', [
        'id' => $userId
    ]);
}

// Redirect to the user control page with a success message
header('Location: user-control.php?status=delete_expired_user');
exit;
?>
