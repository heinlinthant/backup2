<?php

include "sessionCheck.php";

require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

$userId = isset($_GET['id']) ? intval($_GET['id']) : 0;

if ($userId) {
    $database->delete('users', ['id' => $userId]);
} else {
    echo 'Invalid user ID.';
}

header('Location:user-control.php?status=delete'); // Redirect back to the user control page
?>
