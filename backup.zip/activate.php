<?php
date_default_timezone_set('Asia/Rangoon');
require 'vendor/autoload.php';
use Medoo\Medoo;
$blank = "";

include 'database.php';

// Initialize the response array
$permission = "no";

// Check if the request method is GET
if ($_SERVER["REQUEST_METHOD"] == "GET") {
    // Capture the form data
    $users_key = $_GET['users_key'] ?? '';
    $deviceId = $_GET['deviceId'] ?? '';

    // Fetch the user data from the database
    $user = $database->get('users', '*', [
        'users_key' => $users_key,
    ]);

    if ($user) {
        // Checking the key and device Id
        if ($user['deviceId'] == $blank) {
            $database->update('users', ['deviceId' => $deviceId, 'activate' => "true"], ['id' => $user['id']]);
            $permission = "yes";
        } else {
            if ($deviceId === $user['deviceId']) {
                $permission = "yes";
            }
        }

        // Checking the subscription is expired or not
        $expireDate = $user['expireDate'];
        $currentDate = date("Y-m-d");

        if ($expireDate < $currentDate) {
            $permission = "no"; // Expired
        } else {
            $permission = "yes"; // Active
        }
    }

    $arrayData = [
        "permission" => $permission,
    ];

    $finalJson = json_encode($arrayData);
    echo $finalJson;
}
?>
