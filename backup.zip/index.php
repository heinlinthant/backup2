<?php include'sessionCheck.php' ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Welcome from NEXGEN Panel</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
            height: 100vh;
            margin: 0;
            display: flex;
            justify-content: center;
            align-items: center;
            flex-direction: column;
        }

        .header {
            position: absolute;
            top: 70px;
            width: 100%;
            text-align: center;
        }

        .container {
            text-align: center;
        }

        .btn-container {
            margin-top: 10px;
        }

        .btn-custom {
            display: inline-block;
            margin: 20px;
            padding: 15px 40px;
            font-size: 20px;
            color: #000000;
            background-color: #00ff88;
            border: none;
            border-radius: 5px;
            transition: transform 0.3s ease, box-shadow 0.3s ease;
            box-shadow: 0 0 20px rgba(0, 255, 136, 0.6);
            text-transform: uppercase;
            letter-spacing: 2px;
            position: relative;
            overflow: hidden;
            z-index: 1;
        }

        .btn-custom::before {
            content: '';
            position: absolute;
            top: 50%;
            left: 50%;
            width: 300%;
            height: 300%;
            background: rgba(0, 255, 136, 0.2);
            transition: all 0.5s ease;
            transform: translate(-50%, -50%) rotate(45deg);
            z-index: -1;
            opacity: 0;
        }

        .btn-custom:hover::before {
            opacity: 1;
            width: 100%;
            height: 100%;
        }

        .btn-custom:hover {
            transform: scale(1.05);
            box-shadow: 0 0 30px rgba(0, 255, 136, 0.9);
        }

        h2 {
            margin-bottom: 50px;
            color: #00ff88;
            font-size: 2.5rem;
        }

        hr {
            color: #00ff88;
            background-color: #00ff88;
        }

        footer {
            position: absolute;
            bottom: 20px;
            width: 100%;
            text-align: center;
        }
    </style>
</head>
<body>
    <hr>
        <div class="header">
            <h2 class>Welcome from Nexgen Panel</h2>
        </div>

    <div class="container">
        <div class="btn-container">
            <button class="btn btn-custom" onclick="window.location.href='user-control.php'">Control Panel</button>
            <button class="btn btn-custom" onclick="window.location.href='check-user.php'">Check User</button>
        </div>
    </div>

    <footer>
    <hr class="text-light">
        <p><i class="bi bi-code-slash"></i>Developed by Burmese <a href="" class="text-decoration-none text-light">NEXGEN</a></p>
    </footer>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
