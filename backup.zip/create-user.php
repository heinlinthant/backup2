<?php
include "sessionCheck.php";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Create new user</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
        }

        .container {
            background-color: #1e1e1e;
            border-radius: 0.5rem;
            padding: 2rem;
            box-shadow: 0 4px 8px rgba(0,0,0,0.3);
            max-width: 400px;
            width: 100%;
        }

        .form-control {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border: 1px solid #444;
            font-family: Arial, sans-serif;
        }

        .form-control:focus {
            background-color: #2c2c2c;
            color: #e0e0e0;
            border-color: #00ff88;
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.25);
        }

        .btn-primary {
            background-color: #00ff88;
            border: none;
            color: #000000;
            transition: background-color 0.3s ease, transform 0.3s ease;
        }

        .btn-primary:hover {
            background-color: #00cc6a;
            transform: scale(1.05);
        }

        .btn-primary:focus {
            box-shadow: 0 0 0 0.2rem rgba(0, 255, 136, 0.5);
        }

        .form-label {
            color: #e0e0e0;
        }

        .text-danger {
            color: #ff4444;
        }
    </style>
</head>
<body>
    <div class="container mt-2">

         <h4 class="text-center">Create User</h4>
         <hr>
            <form action="create.php" method="post" class="form-dark">
                <div class="mb-3">
                    <label for="username" class="form-label">Username</label>
                    <input type="text" class="form-control" id="username" name="username" required>
                </div>
                <div class="mb-3">
                    <label for="subscription" class="form-label">Subscription (days)</label>
                    <input type="number" class="form-control" id="subscription" name="subscription" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Create User</button>
            </form>
    </div>

    <!-- Link to your local Bootstrap 5 JS file (optional) -->
    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>

