<?php

require 'vendor/autoload.php';
use Medoo\Medoo;

// Initialize Medoo
$database = new Medoo([
    'database_type' => 'mysql',
    'database_name' => '4521007_nexgen', // Replace with your database name
    'server'         => 'fdb1027.runhosting.com', // Replace with your database server
    'username'       => '4521007_nexgen', // Replace with your database username
    'password'       => ')fF9+JI/4+ndI.Xy'  // Replace with your database password
]);