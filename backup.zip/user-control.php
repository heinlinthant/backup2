<?php
include "sessionCheck.php";

require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';
// Fetch user data sorted by ID in descending order
$users = $database->select('users', '*', ['ORDER' => ['id' => 'DESC']]);

// Get the current date
$currentDate = new DateTime();

// Initialize counters
$totalUsers = count($users);
$activeUsers = 0;
$expiredUsers = 0;

// Calculate active and expired users
foreach ($users as $user) {
    $expireDate = new DateTime($user['expireDate']);
    if ($expireDate >= $currentDate) {
        $activeUsers++;
    } else {
        $expiredUsers++;
    }
}

// Check for status in GET parameters
$status = isset($_GET['status']) ? $_GET['status'] : '';
$message = '';
$alertClass = '';

// Determine the message based on the status
switch ($status) {
    case 'create':
        $message = 'User created successfully!';
        $alertClass = 'alert-success';
        break;
    case 'edit':
        $message = 'User details updated successfully!';
        $alertClass = 'alert-info';
        break;
    case 'delete':
        $message = 'User deleted successfully!';
        $alertClass = 'alert-danger';
        break;
    case 'delete_expired_user':
        $message = 'All expired users deleted successfully!';
        $alertClass = 'alert-warning';
        break;
    default:
        $message = '';
        $alertClass = '';
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>User Control Panel</title>
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.1/font/bootstrap-icons.css">
    <link href="https://fonts.googleapis.com/css2?family=Orbitron:wght@400;700&display=swap" rel="stylesheet">
    <style>
        body {
            background-color: #000000;
            color: #00ff88;
            font-family: 'Orbitron', sans-serif;
        }
        
        .container-fluid {
            text-align: right;
            padding: 10px;
            color: #00ff88; 
        }

        .btn-custom {
            background-color: #00ff88;
            color: black;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            transition: all 0.3s ease;
            box-shadow: 0 0 10px rgba(0, 255, 136, 0.7);
        }

        .btn-custom:hover {
            background-color: #00cc6a;
            box-shadow: 0 0 15px rgba(0, 255, 136, 1);
            transform: translateY(-2px);
        }

        .alert {
            color: #000000;
        }

        h3 {
            font-size: 2.5rem;
            margin-bottom: 30px;
        }

        table {
            margin-top: 20px;
        }

        table th, table td {
            text-align: center;
            vertical-align: middle;
        }

        .text-success {
            color: #00ff88 !important;
        }

        .text-danger {
            color: #ff4444 !important;
        }

        .text-warning {
            color: #ffaa00 !important;
        }

        .font1 td {
            font-family: 'Arial', sans-serif;
        }

        .datetime {
            text-align: right;
            font-size: 1rem;
            margin-bottom: 0px;
        }

        .alert {
            color: #000000;
            border-radius: 5px;
            border: none;
            margin-top: 10px;
            font-family: 'Orbitron', sans-serif;
        }

        .alert-success {
            background-color: #00ff88; /* Green background for success */
            color:white; /* Black text for success */
        }

        .alert-info {
            background-color: #00cc6a; /* Slightly darker green background for info */
            color:white; /* Black text for info */
        }

        .alert-warning {
            background-color: #00aa55; /* Even darker green background for warning */
            color:white; /* Black text for warning */
        }

        .alert-danger {
            background-color: #ff4444; /* Red background for danger */
            color:white; /* White text for danger */
        }

        
    </style>


</head>
<body>
    <div class="container-fluid ">
        <div class="datetime">
            <?php date_default_timezone_set('Asia/Rangoon'); echo "Date: ".date('Y-m-d'). " Time ".date('H:i:s'); ?>
        </div>
    </div>
    <div class="container">
        
        <hr>

        <!-- Alert Message -->
        <?php if ($message): ?>
        <div class="alert <?php echo $alertClass; ?> alert-dismissible fade show" role="alert">
            <?php echo $message; ?>
            <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
        </div>
        <?php endif; ?>
        <div class="container">
            <div class="row">
                <div class="col-md-6">
                <a href="index.php" class="btn btn-custom mt-2 mb-2"><i class="bi bi-house me-2"></i>Home</a>
                <a href="create-user.php" class="btn btn-custom mt-2 mb-2"><i class="bi bi-person-add me-2"></i> Create new user</a>
                </div>
                <div class="col-md-6 text-lg-end">
                <a href="change-admin.php" class="btn btn-custom mt-2 mb-2"><i class="bi bi-key-fill me-2"></i>Change Password</a>
                <a href="logout.php" class="btn btn-custom mt-2 mb-2"><i class="bi bi-person-down me-2"></i>Logout</a>
                </div>
            </div>
        </div>

       <hr>
        <!-- Summary Table -->
        <table class="table table-bordered table-dark table-hover">
            <thead>
                <tr>
                    <th>Active Users</th>
                    <th>Expired Users</th>
                    <th>Total Users</th>
                    <th>Action</th>
                </tr>
            </thead>
            <tbody>
                <tr>
                    <td class="text-success"><?php echo $activeUsers; ?></td>
                    <td class="text-danger"><?php echo $expiredUsers; ?></td>
                    <td class="text-warning"><?php echo $totalUsers; ?></td>
                    <td><a href="expire-delete.php" class="btn btn-danger btn-custom" onclick="return confirm('Are you sure you want to delete all expired users?')">Expired Users <i class="bi bi-trash"></i></a></td>
                </tr>
            </tbody>
        </table>

        <!-- User Control Table -->
        <table class="table table-bordered table-dark table-hover">
            <thead>
                <tr>
                    <th>No.</th>
                    <th>Username</th>
                    <th>Key</th>
                    <th>Subscription</th>
                    <th>Expire Date</th>
                    <th>Actions</th>
                </tr>
            </thead>
            <tbody class="font1">
                <?php
                if (!empty($users)) {
                    $count = 1; // Initialize user number
                    foreach ($users as $user) {
                        $expireDate = new DateTime($user['expireDate']);
                        $isExpired = $expireDate < $currentDate;


                        echo '<tr>';
                        echo '<td>' . $count++ . '</td>';
                        echo '<td>' . htmlspecialchars($user['username']) . '</td>';
                        echo '<td> '. htmlspecialchars($user['users_key']) .'</td>';
                        echo '<td>' . htmlspecialchars($user['subscription']) . '&nbsp;Days</td>';
                        echo '<td class="' . ($isExpired ? 'text-danger' : 'text-success') . '">';
                        echo htmlspecialchars($user['expireDate']);
                        echo '</td>';
                        echo '<td>';
                        echo '<a href="edit-user.php?id=' . htmlspecialchars($user['id']) . '" class="btn btn-info btn-sm btn-custom"><i class="bi bi-pencil"></i></a> ';
                        echo '<a href="delete.php?id=' . htmlspecialchars($user['id']) . '" class="btn btn-danger btn-sm btn-custom" onclick="return confirm(\'Are you sure you want to delete this user?\')"><i class="bi bi-trash3"></i></a>';
                        echo '</td>';
                        echo '</tr>';
                    }
                } else {
                    echo '<tr><td colspan="6">No users found.</td></tr>';
                }
                ?>
            </tbody>
        </table>
    </div>

    <script src="js/bootstrap.bundle.min.js"></script>
</body>
</html>
