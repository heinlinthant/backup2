<?php
date_default_timezone_set('Asia/Rangoon');
include "sessionCheck.php";

require 'vendor/autoload.php';
use Medoo\Medoo;

include 'database.php';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture the form data
    $userId = isset($_POST['id']) ? intval($_POST['id']) : 0;
    $username = $_POST['username'];
    $users_key = $_POST['users_key'];
    $deviceId = $_POST['deviceId'];
    $subscription = $_POST['subscription'];

    // Get the user's current expire date
    $user = $database->get('users', '*', ['id' => $userId]);
    if (!$user) {
        echo 'User not found.';
        exit;
    }

    // Calculate expireDate as the sum of createdDate and subscription days
    $startDate = $user['startDate'];
    $expireDate = date('Y-m-d',strtotime($startDate.'+'. $subscription .'days'));
;

    // Update user data in the database
    $database->update('users', [
        'username' => $username,
        'users_key' => $users_key,
        'deviceId' => $deviceId,
        'subscription' => $subscription,
        'expireDate' => $expireDate
    ], ['id' => $userId]);

    header('Location: user-control.php?status=edit'); // Redirect to the user control page
    exit;
}
?>
