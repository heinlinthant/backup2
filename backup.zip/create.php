<?php
date_default_timezone_set('Asia/Rangoon');
require 'vendor/autoload.php';

use Medoo\Medoo;

include 'database.php';
include 'key.php';
$activate = "false";

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Capture and sanitize input
    $username = filter_input(INPUT_POST, 'username', FILTER_SANITIZE_SPECIAL_CHARS);
    $deviceId = filter_input(INPUT_POST, 'deviceId', FILTER_SANITIZE_SPECIAL_CHARS);
    $subscription = filter_input(INPUT_POST, 'subscription', FILTER_VALIDATE_INT);

    // Validate input
    if (empty($username) || $subscription === false) {
        die('Invalid input data.');
    }

    // Calculate the expiration date
    $expireDate = date('Y-m-d', strtotime('+' . $subscription . ' days'));

    // Insert data into the 'users' table
    $database->insert('users', [
        'username'     => $username,
        'users_key'    => $generateKey,
        'subscription' => $subscription,
        'activate'     => $activate,
        'expireDate'   => $expireDate,
        'startDate'    => date("Y-m-d")
    ]);

    // Check if the insert was successful
    if ($database->id()) {
        header("location: user-control.php?status=create");
    } else {
        echo 'Error saving data.';
    }
}
?>
