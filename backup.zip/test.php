<?php
function zipData($source, $destination) {
    if (!extension_loaded('zip') || !file_exists($source)) {
        return false;
    }

    $zip = new ZipArchive();
    if (!$zip->open($destination, ZipArchive::CREATE)) {
        return false;
    }

    $source = realpath($source);

    if (is_dir($source)) {
        $iterator = new RecursiveDirectoryIterator($source, RecursiveDirectoryIterator::SKIP_DOTS);
        $files = new RecursiveIteratorIterator($iterator, RecursiveIteratorIterator::SELF_FIRST);

        foreach ($files as $file) {
            $filePath = realpath($file);
            if (is_dir($filePath)) {
                $zip->addEmptyDir(str_replace($source . '/', '', $filePath . '/'));
            } else if (is_file($filePath)) {
                $zip->addFile($filePath, str_replace($source . '/', '', $filePath));
            }
        }
    } else if (is_file($source)) {
        $zip->addFile($source, basename($source));
    }

    return $zip->close();
}

// Define the source directory and destination zip file
$source = __DIR__; // Current directory where the script is located
$destination = __DIR__ . '/backup.zip'; // The zip file will be saved as backup.zip in the same directory

// Create the zip file
if (zipData($source, $destination)) {
    echo 'Backup created successfully at ' . $destination;
} else {
    echo 'Failed to create backup.';
}
?>
